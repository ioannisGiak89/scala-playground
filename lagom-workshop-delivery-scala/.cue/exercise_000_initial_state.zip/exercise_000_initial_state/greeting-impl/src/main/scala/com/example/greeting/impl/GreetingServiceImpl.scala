package com.example.greeting.impl

import com.example.greeting.api.GreetingService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.persistence.PersistentEntityRegistry

import scala.concurrent.Future

/**
  * Implementation of the GreetingService.
  */
class GreetingServiceImpl(persistentEntityRegistry: PersistentEntityRegistry) extends GreetingService {

  override def hello(id: String) = ServiceCall { _ =>

    //todo update this to greet using the name passed in
    Future.successful("you should change me!")
  }

}

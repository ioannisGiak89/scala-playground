package com.example.greeting.impl

import akka.Done
import com.datastax.driver.core._
import com.lightbend.lagom.scaladsl.persistence.cassandra.{CassandraReadSide, CassandraSession}
import com.lightbend.lagom.scaladsl.persistence.{AggregateEventTag, ReadSideProcessor}

import scala.concurrent.{ExecutionContext, Future}

class GreetingRepository(session: CassandraSession)(implicit ec: ExecutionContext) {

  def getGuestGreeting(id: String) = {
    session.selectAll("SELECT * FROM greeting WHERE id = ?", id).map( rows =>
    rows.map(row => row.getString("message")).seq
    )
  }

  def getAllGreetings() = {
    session.selectAll("SELECT * FROM greeting").map( rows => {

      rows.map( row => {
        val (id, message) = (row.getString("id"), row.getString("message"))

        s"guest: $id , greeting: $message"
      }).seq
    })
  }
}


class GreetingEventProcessor(session: CassandraSession, readSide: CassandraReadSide)(implicit ec: ExecutionContext)
  extends ReadSideProcessor[GreetingEvent] {
  private var insertCustomGreetingStatement: PreparedStatement = null

  def buildHandler = {
    readSide.builder[GreetingEvent]("greetingEventOffset")
      .setGlobalPrepare(createTables)
      .setPrepare(_ => prepareStatements())
      .setEventHandler[GreetingMessageChanged](e => insertGreeting(e.entityId, e.event))
      .build
  }

  override def aggregateTags :Set[AggregateEventTag[GreetingEvent]] = GreetingEvent.Tag.allTags

  private def createTables() = for {
    _ <- session.executeCreateTable("""CREATE TABLE IF NOT EXISTS greeting (id text, message text, PRIMARY KEY (id, message))""")

  } yield Done

  private def prepareStatements() = {
    for {
      insertItemCreator <- session.prepare("""
          INSERT INTO greeting (id, message) VALUES (?, ?)
      """)
    } yield {
      insertCustomGreetingStatement = insertItemCreator
      Done
    }
  }

  private def insertGreeting(id: String, greeting: GreetingMessageChanged) = {
    Future.successful(List(
      insertGreetingCreator(id, greeting)
    ))
  }

  private def insertGreetingCreator(id: String, greeting: GreetingMessageChanged) = {
    insertCustomGreetingStatement.bind(id, greeting.message)
  }
}



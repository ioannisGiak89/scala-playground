package com.example.greeting.impl

import akka.NotUsed
import com.example.greeting.api
import com.example.greeting.api.GreetingService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.api.broker.Topic
import com.lightbend.lagom.scaladsl.broker.TopicProducer
import com.lightbend.lagom.scaladsl.persistence.{EventStreamElement, PersistentEntityRegistry}

import scala.collection.immutable
import scala.concurrent.Future

/**
  * Implementation of the GreetingService.
  */
class GreetingServiceImpl(persistentEntityRegistry: PersistentEntityRegistry, repository: GreetingRepository) extends GreetingService {

  override def hello(id: String) = ServiceCall { _ =>
    // Look up the Greeting entity for the given ID.
    val ref = persistentEntityRegistry.refFor[GreetingEntity](id)

    // Ask the entity the Hello command.
    ref.ask(Hello(id))
  }

  override def useGreeting(id: String) = ServiceCall { request =>
    // Look up the Greeting entity for the given ID.
    val ref = persistentEntityRegistry.refFor[GreetingEntity](id)

    // Tell the entity to use the greeting message specified.
    ref.ask(UseGreetingMessage(request.message))
  }

  /**
    * Example: curl http://localhost:9000/api/hello/greetings/Alice
    */
  override def getGreetings(id: String): ServiceCall[NotUsed, Seq[String]] = ServiceCall {
    _ => repository.getGuestGreeting(id)
  }

  /**
    * Example: curl http://localhost:9000/api/greetings/all
    */
  override def getAllGreetings: ServiceCall[NotUsed, Seq[String]] = ServiceCall {
    _ => repository.getAllGreetings()
  }

  override def greetingsTopic(): Topic[api.GreetingMessageChanged] =
    TopicProducer.taggedStreamWithOffset (GreetingEvent.Tag.allTags.to[immutable.Seq]) { (tag, offset) =>
      persistentEntityRegistry.eventStream(tag, offset).filter(e =>
        e.event.isInstanceOf[GreetingMessageChanged]
      ).mapAsync(1) { event =>
          val messageChanged = convertEvent(event)
          println(s"*** publishing message: $messageChanged ***")
          Future.successful(convertEvent(event), event.offset)
        }
    }

  private def convertEvent(helloEvent: EventStreamElement[GreetingEvent]): api.GreetingMessageChanged = {
    helloEvent.event match {
      case GreetingMessageChanged(msg) => api.GreetingMessageChanged(helloEvent.entityId, msg)
    }
  }
}

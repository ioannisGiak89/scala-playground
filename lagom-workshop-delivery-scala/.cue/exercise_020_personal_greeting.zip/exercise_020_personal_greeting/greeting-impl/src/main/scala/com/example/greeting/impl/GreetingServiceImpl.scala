package com.example.greeting.impl

import com.example.greeting.api.GreetingService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.persistence.PersistentEntityRegistry

import scala.concurrent.Future

/**
  * Implementation of the GreetingService.
  */
class GreetingServiceImpl(persistentEntityRegistry: PersistentEntityRegistry) extends GreetingService {

  override def hello(id: String) = ServiceCall { _ =>
    // Look up the Greeting entity for the given ID.
    val ref = persistentEntityRegistry.refFor[GreetingEntity](id)

    // Ask the entity the Hello command.
    ref.ask(Hello(id))
  }

  override def useGreeting(id: String) = ServiceCall { request =>
    // Look up the Greeting entity for the given ID.
    val ref = persistentEntityRegistry.refFor[GreetingEntity](id)

    // Tell the entity to use the greeting message specified.
    Future.successful("Ask the entity to use the greeting message specified in the request object")
    ref.ask(UseGreetingMessage(request.message))
  }

}

exercise_030_finding_greetings

## Exercise 030 > Finding Greetings

### How can see all of the personal greetings? Can we see all of the greetings that a guest has used? 
* We need a way to update the view side so that we can search for greeting related data. 
* We will create a read-side processor to update the read side representation. 
* We will create a repository class to interact with the read-side related data 
in the database. 



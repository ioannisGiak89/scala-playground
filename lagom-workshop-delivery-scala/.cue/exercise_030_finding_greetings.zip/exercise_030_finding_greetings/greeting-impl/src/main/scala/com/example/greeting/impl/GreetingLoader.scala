package com.example.greeting.impl

import com.example.greeting.api.GreetingService
import com.lightbend.lagom.scaladsl.api.ServiceLocator
import com.lightbend.lagom.scaladsl.api.ServiceLocator.NoServiceLocator
import com.lightbend.lagom.scaladsl.broker.kafka.LagomKafkaComponents
import com.lightbend.lagom.scaladsl.devmode.LagomDevModeComponents
import com.lightbend.lagom.scaladsl.persistence.cassandra.CassandraPersistenceComponents
import com.lightbend.lagom.scaladsl.server.{LagomApplication, LagomApplicationContext, LagomApplicationLoader}
import com.softwaremill.macwire._
import play.api.libs.ws.ahc.AhcWSComponents

class GreetingLoader extends LagomApplicationLoader {

  override def load(context: LagomApplicationContext): LagomApplication =
    new GreetingApplication(context) {
      override def serviceLocator: ServiceLocator = NoServiceLocator
    }

  override def loadDevMode(context: LagomApplicationContext): LagomApplication =
    new GreetingApplication(context) with LagomDevModeComponents

  override def describeServices = List(
    readDescriptor[GreetingService]
  )
}

abstract class GreetingApplication(context: LagomApplicationContext)
  extends LagomApplication(context)
    with CassandraPersistenceComponents
    with LagomKafkaComponents
    with AhcWSComponents {

  lazy val greetingRepository = wire[GreetingRepository]

  // Bind the service that this server provides
  override lazy val lagomServer = serverFor[GreetingService](wire[GreetingServiceImpl])

  // Register the JSON serializer registry
  override lazy val jsonSerializerRegistry = GreetingSerializerRegistry

  // Register the Greeting persistent entity
  persistentEntityRegistry.register(wire[GreetingEntity])

  readSide.register(wire[GreetingEventProcessor])
}

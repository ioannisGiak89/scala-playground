exercise_010_simply_hello

## Exercise 010 > Simply Hello

### A stateful way to say hello 

* Use entity state to derive the greeting. 
* A read-only command is being used, so state is not changing here, only the person to be greeted. We are grabbing a 
persistent entity by its ID and using current state (Hello.class)
* As no state is changed, no event is generated.



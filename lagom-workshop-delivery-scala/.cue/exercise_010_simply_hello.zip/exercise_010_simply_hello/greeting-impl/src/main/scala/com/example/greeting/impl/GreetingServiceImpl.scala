package com.example.greeting.impl

import com.example.greeting.api.GreetingService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.persistence.PersistentEntityRegistry

import scala.concurrent.Future

/**
  * Implementation of the GreetingService.
  */
class GreetingServiceImpl(persistentEntityRegistry: PersistentEntityRegistry) extends GreetingService {

  override def hello(id: String) = ServiceCall { _ =>
    // Look up the Greeting entity for the given ID.
    val ref = persistentEntityRegistry.refFor[GreetingEntity](id)

    // todo Ask the entity the Hello command.
    Future.successful("Use the ref to ask the entity the Hello command. Check GreetingEntity for Hello Command usage")
  }
}
